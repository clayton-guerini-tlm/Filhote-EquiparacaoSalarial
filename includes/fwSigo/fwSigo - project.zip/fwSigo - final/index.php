<?php /** Versão 3.2.0 **/

$root = './../../../';

// include "{$root}includes/funcoes.php";
// include "{$root}includes/valida_sessao.php";

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if(!isset($_GET['mainapp']) || !isset($_GET['app'])) {
    header("Location: ?mainapp=home&app=home");
}

// $menuSigo = RetornaMenuSigo('');

?>

<!DOCTYPE html>
<html>
    <head>
        <title>:: <?=htmlentities('FRAMEWORK SIGO')?> ::</title>
        
        <link type="image/x-icon" rel="shortcut icon" href="<?=$root?>favicon.ico" />
        
        <meta http-equiv="Content-Type" content="text/html" charset="UTF-8">
        <meta http-equiv="pragma" content="no-cache">
        <meta http-equiv="expires" content="-1">
        <meta name="robots" content="noindex,nofollow">
        
        <script type="text/javascript" src="<?=$root?>includes/fwSigo/library/jquery-3.3.1.min.js"></script>
        <script type="text/javascript">

        	const TITULO_DEFAULT = 'FW SIGO';
        
            $.ajaxSetup({
                
                url: './app/ajax.php',
                dataType: 'json',
                cache: false,
                type: 'POST',
                error: function(objectError, error, message) {

                    alerta('error', 'Ocorreu um erro fatal.', function(){
                        console.log(objectError, error, message);
                    });

                }

            });

            $.urlParam = function(name){
                var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
                if (results == null) return null; else return decodeURI(results[1]) || 0;
            }
            
        </script>
        
        <script type="text/javascript" src="<?=$root?>includes/fwSigo/library/modal/redmon-jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
        <script type="text/javascript" src="<?=$root?>includes/fwSigo/library/jquery-confirm.min.js"></script>
        <script type="text/javascript" src="<?=$root?>includes/fwSigo/library/mensagem.js"></script>
        <script type="text/javascript" src="<?=$root?>includes/fwSigo/library/modal/janela.js"></script>
        <script type="text/javascript" src="<?=$root?>includes/fwSigo/library/string.js"></script>
        
        <link type="text/css" rel="stylesheet" href="<?=$root?>includes/fwSigo/library/modal/redmon-jquery-ui-1.12.1.custom/jquery-ui.min.css">
        <link type="text/css" rel="stylesheet" href="<?=$root?>includes/fwSigo/library/jquery-confirm.min.css">
        <link type="text/css" rel="stylesheet" href="<?=$root?>css/index.css">
        <link type="text/css" rel="stylesheet" href="<?=$root?>css/menu.css">
        
    </head>
    <body>
    	<div id="janela"></div>
    	<div id="div_geral">
            <div class="div_topo">
                <a href="?mainapp=home&amp;app=home">
                    <img src="<?=$root?>imagens/banner_topo.jpg" id="BannerSigoTelemont" alt="Banner Sigo Telemont">
                </a>
                <div class="div_menu"><?php /* utf8_encode($menuSigo) */ ?></div>
            </div>
            <div class="div_meio">
                <?php
    
                    include_once "./includes/{$_GET['mainapp']}/inc_{$_GET['app']}.php";
                    $noCache = microtime(true);
                    
                    $jsFile = "./includes/{$_GET['mainapp']}/assets/{$_GET['app']}.js";
                    $cssFile = "./includes/{$_GET['mainapp']}/assets/{$_GET['app']}.css";
                    
                    if(file_exists($jsFile)) {    
                        echo '<script type="text/javascript" src="'.$jsFile.'?'.$noCache.'"></script>';
                    }
                    
                    if(file_exists($cssFile)) {
                        echo '<link type="text/css" rel="stylesheet" href="'.$cssFile.'?'.$noCache.'">';
                    }
                    
                ?>
            </div>
        </div>
        
	</body>
</html>