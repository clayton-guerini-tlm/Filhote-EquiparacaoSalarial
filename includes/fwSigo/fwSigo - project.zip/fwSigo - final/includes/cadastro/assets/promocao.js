$('.abrirFecharFormulario').click(function() {

	if($('.form-header').css('display') == 'none') {
		$('.form-header').show('slow');
	} else {
		$('.form-header').hide('slow');
	}
	
	$('input[type="text"]').val('');
	$('#pesquisarFuncionario').focus();

});

$('#pesquisarFuncionario').blur(function(e) {

	var pesquisarFuncionario = $(this).val();
	$('#funcionarios').empty();
	
	if($.trim(pesquisarFuncionario) != '') {
		
		$.ajax({
			data: {'funcaoAjax' : 'CCadastroPromocao::pesquisarFuncionario', 'pesquisarFuncionario' : pesquisarFuncionario}
		}).done(function (response) {
			
			if(response.success) {
				
				var linha = '<div>{0} {1}</div>';
				var img = '<img value="{0}">';
				
				$.each(response.data, function(key, value){
					$('#funcionarios').append(linha.format(value.fun_nome, img.format(value.fun_chapa)));
				});
				
			}else {
				alerta(response.data == 'v' ? 'warning' : 'error', response.message, function(){
					console.log(response.data);
				});
			}
			
		});
		
	}
	
});

$(document).on('click', '#funcionarios img', function(){
	
	var chapa = $(this).attr('value');
	
	$.ajax({
		data: {'funcaoAjax' : 'CCadastroPromocao::abrirPromocao', 'chapa' : chapa}
	}).done(function (response) {
		
		if(response.success) {
			alerta('success', response.message, function(){
				window.location.href = '?mainapp=promocao&app=promocoes';
			});
		}else {
			alerta(response.data == 'v' ? 'warning' : 'error', response.message, function(){
				console.log(response.data);
			});
		}
		
	});
	
});