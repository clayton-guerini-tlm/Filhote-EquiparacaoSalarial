<div class="page-header">abertura de promoção</div>

<div class="bar">
	<img src="../../../imagens/vale_transporte/cadastro.png" class="abrirFecharFormulario">
</div>

<div class="form-header form-body-label" style="display: none;">
    <table width="100%">
    	<thead>
    		<tr>
    			<th colspan="100%">
    				pesquisar funcionário
    			</th>
    		</tr>
    	</thead>
    	<tbody>
    		<tr>
    			<td style="width: 30%;">
    				<label for="pesquisarFuncionario">Descrição:</label>
    			</td>
    			<td>
    				<input type="text" id="pesquisarFuncionario" placeholder="Informe a chapa ou parte do nome do funcionário">
    			</td>
    		</tr>
    		<tr>
    			<td colspan="100%" style="text-align: center;">
    				<input type="button" class="confirmar" value="Confirmar">
                	<input type="button" class="cancelar" value="Cancelar">
    			</td>
    		</tr>
    	</tbody>
    </table>
</div>

<!-- <div id="funcionarios"></div> -->