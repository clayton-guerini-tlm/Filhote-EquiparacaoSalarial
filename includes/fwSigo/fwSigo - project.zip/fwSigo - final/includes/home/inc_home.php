<!--
<form id="frmHome" name="frmHome">
	<input type="hidden" name="funcaoAjax" value="CHome::save" required="required">
    <input type="text" name="id_menu" value="SIGO_AREA1_MG_STD" required="required">
    <input type="text" name="aplicacao" = value="relatorio" required="required">
    <input type="text" name="rotina" value="evolucao_programador_ac" required="required">
    <input type="text" name="usuario" value="068876" required="required">
    <input type="text" name="data_log" value="2020-01-01 00:00:00" required="required">
    <input type="submit" value="Salvar">
</form>

<div id="id"></div>
-->

