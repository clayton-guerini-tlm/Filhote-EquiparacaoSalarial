function processar(res) {
    console.log(res);
}

$.ajax({
    data: { 'funcaoAjax' : 'CHomeHome::load', 'callBack' : 'processar', 'dados' : 'teste'}
});

//janela('http://192.168.5.51/SIGO_INTEGRADO_3/', 'ACESSANDO O SIGÃO', 1024, 600, function(){ alert('Irá fechar o modal!'); });
//$.ajax({
//	data: {'funcaoAjax' : 'CHome::load'}
//}).done(function (response) {
//	
//	confirma('Deseja exibir o alerta?', function(){
//		alerta('success', 'Teste de Alerta', function(){ alert('OK!'); });
//	},
//	function(){
//		alert('Sem alerta bonitão!');
//	})
//	
//	console.log(response);
//	
//}).fail(function(objectError, error, message) {
//	console.log(objectError);
//	console.log(error);
//	console.log(message);
//});
//
//$('#frmHome').submit(function(e){
//	e.preventDefault();
//	
//	$.ajax({
//		data: new FormData(this),
//		processData: false,
//		contentType: false
//	}).done(function (response) {
//		
//		if(response.success) {
//			$('#id').html(response.data);
//		}else {
//			console.log(response.errors);
//		}
//		
//	}).fail(function(objectError, error, message) {
//		console.log(objectError);
//		console.log(error);
//		console.log(message);
//	});
//	
//});

