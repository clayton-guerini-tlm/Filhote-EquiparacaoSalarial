<?php

$idPromocao = $_GET['idPromocao'];

function __autoload($class) {
    $file = $class . '.php';
    if(!file_exists($file)) {
        $dirs = array('.', './app/core', './app/controller', './app/model', './app/classes', './app/helper', './../../../includes/fwSigo');
        foreach($dirs as $dir) {
            $file = "{$dir}/{$class}.php";
            if(file_exists($file)) {
                require_once $file; break;
            }
        }
    } else require_once $file;
}

$promocao = DadosProjeto::buscarPromocao($idPromocao);

switch ($_GET['p']) {
    
    case 1:
        
        DadosProjeto::construir($promocao, DadosProjeto::dadosFuncionario);
        
    break;
    
    default:
        echo 'ação de página inexistente';
    break;
}

?>