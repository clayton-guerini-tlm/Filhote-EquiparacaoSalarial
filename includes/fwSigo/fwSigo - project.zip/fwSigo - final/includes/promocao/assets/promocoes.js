$.ajax({
	data: {'funcaoAjax' : 'CPromocaoPromocoes::carregarPromocoesAbertas'}
}).done(function (response) {
	
	if(response.success) {
		
		var linha = '<div>{0} - {1} {2} {3} {4} - {5} {6}</div>';
		var img = '<img value="{0}">';
		
		$.each(response.data, function(key, value){
			$('#promocoes').append(linha.format(value.chapaPromocao, value.nomePromocao, value.dthrAberturaPromocao, value.statusPromocao, value.usuarioAberturaPromocao, value.nomeUsuarioAbertura, img.format(value.idPromocao)));
		});
		
	}else {
		alerta(response.data == 'v' ? 'warning' : 'error', response.message, function(){
			console.log(response.data);
		});
	}
	
});

$(document).on('click', '#promocoes img', function(){
	
	var idPromocao = $(this).attr('value');
	
	$.ajax({
		data: {'funcaoAjax' : 'CPromocaoPromocoes::atualizarSituacaoPromocaoAndamento', 'idPromocao' : idPromocao}
	}).done(function (response) {
		
		if(response.success) {
			window.location.href = '?mainapp=promocao&app=analise&idPromocao={0}&p=1'.format(response.data);
		}else {
			alerta('error', response.message, function(){
				console.log(response.data);
			});
		}
		
	});
	
});