<?php class TabelaPrincipal extends DClass {

    public $idTabelaPrincipal;
    public $descricaoTabelaPrincipal;

}