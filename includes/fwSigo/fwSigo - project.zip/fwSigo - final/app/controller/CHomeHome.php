<?php

final class CHomeHome extends Controller {

    public static function load() {

        $model = new MTabelaPrincipal();
        $res = $model->buscarTodasTabelasPrincipais();

        // return self::response(false, 'Este é um erro tratado', 'mysql_error 220 syntax');
        // return self::response(false, 'Você está sendo barrado por uma validação', 'v');
        return self::response(true, 'Sucesso!', $res);

    }

}