<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

$core = $_SERVER['DOCUMENT_ROOT'] . '/SIGO_INTEGRADO_3/includes/fwsigo/core/';

require_once $core . 'ErrorHandler.php';
require_once $core . 'Root.php';



function __autoload($class) {
    
    $file = Root::getRoot() . $class . '.php';
    
    if(!file_exists($file)) {

        $dirs = array('.', './controller', './model', './classes', './helper');
        
        foreach($dirs as $dir) {

            $file = "{$dir}/{$class}.php";
            
            if(file_exists($file)) {
                require_once $file;
                break;
            }
            
        }
        
    }else {
        require_once $file;   
    }
    
}

if (isset($_POST['funcaoAjax'])) {
    
    $controllerName = explode('::', $_POST['funcaoAjax']);
    $controllerName = current($controllerName);
    
    $returnRequest = call_user_func("{$controllerName}::executeFunction", $_POST) or
    die(json_encode(array('success' => false, 'message' => 'Função inválida', 'data' => $_POST, 'errors' => $GLOBALS['_ERRORS'])));

    if (is_array($returnRequest)) {
        die(json_encode($returnRequest));
    } else {
        die($returnRequest);
    }
    
} else {
    die(json_encode(array('success' => false, 'message' => 'Função não informada', 'data' => $_POST, 'errors' => $GLOBALS['_ERRORS'])));
}