<?php

class MMysql extends Model {

    public function __construct() {
        parent::__construct('local', 'mysql', 'COMysql');
    }

    public function buscarUsers() {

        $query = 'select * from user';

        $con = $this->getConnection();

        $statement = $con->prepare($query);
        $statement->execute();
        
        return $statement->fetchAll(PDO::FETCH_CLASS, 'stdClass');

    }


}
