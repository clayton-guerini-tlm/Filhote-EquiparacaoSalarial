<?php class MTabelaPrincipal extends Model  {

    public function __construct() {
        parent::__construct('local', 'base_dados', 'localBase');
    }

    public function buscarTodasTabelasPrincipais() {

        $query = 'select idTabelaPrincipal, descricaoTabelaPrincipal from tbl_tabela_principal';

        $con = $this->getConnection();

        $statement = $con->prepare($query);
        $statement->execute();
        
        return $statement->fetchAll(PDO::FETCH_CLASS, 'TabelaPrincipal');

    }

}